# TODO 🚧

Your new site is all yours so it doesn't matter if you break it! Try editing the code–add a button element that moves when the user clicks it.

In `index.html`, add this code on the line after the comment with `ADD BUTTON HERE` in it (you can copy and paste the button element HTML):

```html
<button>
    Click me!
</button>
```

Look at the page to see the button. Click it!

Open `script.js` to see the script that makes the button move.

## Keep going! 🚀

Try adding more properties to the CSS `dipped` style for the button to see how the changes appear on click.
